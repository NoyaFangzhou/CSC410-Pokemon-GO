#!C:\Users\nevgivin\Anaconda2\python.exe

import cgi
import cgitb


print 'Content-Type: text/html'
print

print '''<html>
  <head>
    <title>Lecture 3 Demo Python Script</title>
    <style type="text/css">
      h1 {
          font-size: 100px;
          font-family: monospace;
      }
      .red_text {
          color: red;
      }
    </style>
  </head>
  <body>
'''